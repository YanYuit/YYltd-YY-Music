export default function PrivacyPolicy() {
  return (
    <div className="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
      <h1 className="text-3xl font-bold mb-6">隐私政策</h1>
      <p className="mb-4">
        言语AI-Music
        尊重并保护所有使用服务用户的个人隐私权。为了给您提供更准确、更有个性化的服务，我们会按照本隐私权政策的规定使用和披露您的个人信息。
      </p>
      {/* Add more detailed privacy policy content here */}
    </div>
  )
}

