"use client"

import { useState, useRef, useEffect } from "react"
import { HexColorPicker } from "react-colorful"
import { Canvas } from "@react-three/fiber"
import { Text, OrbitControls } from "@react-three/drei"

function EmotionColorWheel() {
  const [color, setColor] = useState("#ffffff")

  const handleColorChange = (newColor: string) => {
    setColor(newColor)
    // Here you would implement the logic to adjust MV color tone, lighting, and music EQ
    console.log("Adjusting MV and music based on color:", newColor)
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">情绪色轮</h3>
      <HexColorPicker color={color} onChange={handleColorChange} />
      <div className="flex items-center space-x-2">
        <div className="w-6 h-6 rounded-full" style={{ backgroundColor: color }}></div>
        <span>{color}</span>
      </div>
    </div>
  )
}

function ThreeDTimeline({
  colorTheme = { primary: "#4A00E0", secondary: "#8E2DE2", accent: "#FF4E00" },
}: {
  colorTheme?: { primary: string; secondary: string; accent: string }
}) {
  return (
    <Canvas>
      <OrbitControls />
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} />
      <group>
        <Text position={[-2, 2, 0]} color="white" fontSize={0.5}>
          音乐波形
        </Text>
        <Text position={[0, 0, 0]} color="white" fontSize={0.5}>
          视频画面
        </Text>
        <Text position={[2, -2, 0]} color="white" fontSize={0.5}>
          歌词文字
        </Text>
        <mesh position={[-2, 1, 0]}>
          <boxGeometry args={[4, 0.5, 0.1]} />
          <meshStandardMaterial color={colorTheme.primary} />
        </mesh>
        <mesh position={[0, -1, 0]}>
          <boxGeometry args={[4, 0.5, 0.1]} />
          <meshStandardMaterial color={colorTheme.secondary} />
        </mesh>
        <mesh position={[2, -3, 0]}>
          <boxGeometry args={[4, 0.5, 0.1]} />
          <meshStandardMaterial color={colorTheme.accent} />
        </mesh>
      </group>
    </Canvas>
  )
}

function ARPreview() {
  const videoRef = useRef<HTMLVideoElement>(null)

  useEffect(() => {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      navigator.mediaDevices
        .getUserMedia({ video: true })
        .then((stream) => {
          if (videoRef.current) {
            videoRef.current.srcObject = stream
          }
        })
        .catch((error) => console.error("Error accessing camera:", error))
    }
  }, [])

  return (
    <div className="relative w-full h-64">
      <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="bg-blue-500/50 p-4 rounded">AR MV 预览区域</div>
      </div>
    </div>
  )
}

export default function InnovativeInteractions({
  colorTheme = { primary: "#4A00E0", secondary: "#8E2DE2", accent: "#FF4E00" },
}: {
  colorTheme?: { primary: string; secondary: string; accent: string }
}) {
  return (
    <div className="bg-deep-space-blue/50 backdrop-blur-md rounded-lg p-6 space-y-8">
      <h2 className="text-2xl font-semibold mb-4">创新交互设计</h2>

      <EmotionColorWheel />

      <div className="h-64">
        <h3 className="text-lg font-semibold mb-2">三维时间轴</h3>
        <ThreeDTimeline colorTheme={colorTheme} />
      </div>

      <div>
        <h3 className="text-lg font-semibold mb-2">AR实时预览</h3>
        <ARPreview />
      </div>
    </div>
  )
}

